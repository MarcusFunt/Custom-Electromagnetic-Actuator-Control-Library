# EMAC files to upload

Copy these files into the repository root, preserving paths:

- `tools/python/emac_sim/visual.py`
- `tools/python/emac_sim/estimator.py`
- `examples/configs/pendulum_softiron_1gate.toml`

Then run:

```powershell
python -m pip install -e .[dev]
python -m pytest
python -m emac_sim.visual --config examples/configs/pendulum_softiron_1gate.toml --outdir build/visual --open
```

Notes:

- `estimator.py` fixes the first-half-swing direction sign so the predicted waveform is not inverted.
- `visual.py` adds the visualizer UX improvements: accessible colors, RMS metrics, JSON export, overlay-run loading, crossing tooltips, and a clearer config/metrics sidebar.
- The HTML visualizer is still a viewer for generated simulation data. It does not re-run the physical simulation in the browser when you change parameters; regenerate with `emac-visual --config ...` after editing TOML values.
